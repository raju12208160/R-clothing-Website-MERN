import p1_img from './product-5.jpg'
import p2_img from './product-2.jpg'
import p3_img from './jacket-3.jpg'
import p4_img from './blazer-1.jpg'

let data_product = [
  {
    id:2,
    name:"black Printed Leaves",
    image:p1_img,
    new_price:890.00,
    old_price:990.50,
  },
  {id:3,
    name:"black Sweartshirt",
    image:p2_img,
    new_price:699,
    old_price:899,
  },
  {id:14,
    name:"Black Jacket",
    image:p3_img,
    new_price:1899,
    old_price:1999,
  },
  {id:16,
    name:"Black Blazer",
    image:p4_img,
    new_price:3399,
    old_price:3499,
  },
];

export default data_product;
